(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_ef44d26b._.js",
  "static/chunks/node_modules_91192fac._.js"
],
    source: "dynamic"
});
