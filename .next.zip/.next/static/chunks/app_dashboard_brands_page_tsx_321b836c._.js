(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_23c401cc._.js",
  "static/chunks/node_modules_0e2de0a1._.js"
],
    source: "dynamic"
});
