(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__33bd1d78._.css",
  "static/chunks/node_modules_8bb04d90._.js",
  "static/chunks/_4b42755b._.js"
],
    source: "dynamic"
});
