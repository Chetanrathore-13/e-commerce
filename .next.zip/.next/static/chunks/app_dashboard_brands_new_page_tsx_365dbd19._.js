(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_43837c1e._.js",
  "static/chunks/components_1a48523d._.js"
],
    source: "dynamic"
});
