(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_07f90ba5._.js",
  "static/chunks/components_0b2f388d._.js"
],
    source: "dynamic"
});
