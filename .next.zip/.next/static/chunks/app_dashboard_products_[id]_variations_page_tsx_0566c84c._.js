(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4e140ef0._.js",
  "static/chunks/components_3e1d3613._.js"
],
    source: "dynamic"
});
