(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0c309663._.js",
  "static/chunks/components_35d2907a._.js"
],
    source: "dynamic"
});
