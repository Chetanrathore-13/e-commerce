(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f0594cb7._.js",
  "static/chunks/components_b65d1e78._.js"
],
    source: "dynamic"
});
