(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_713e9c48._.js",
  "static/chunks/node_modules_a7af95c8._.js"
],
    source: "dynamic"
});
