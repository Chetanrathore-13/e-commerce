(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_f240f67a._.js",
  "static/chunks/node_modules_recharts_es6_f5341134._.js",
  "static/chunks/node_modules_6266aa26._.js",
  "static/chunks/components_9f9ba4e9._.js"
],
    source: "dynamic"
});
